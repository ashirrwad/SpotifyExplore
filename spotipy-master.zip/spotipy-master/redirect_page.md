Spotipy Authorization Page
===========================

If you are here, you are probably running a Spotipy test app that has been asked to authenticate the user.
Now you just need to cut/paste the URL into the terminal at the prompt asking:

    Enter the URL you were redirected to:
    

And you should be good to go
